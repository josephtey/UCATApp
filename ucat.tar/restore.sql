--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.3
-- Dumped by pg_dump version 12.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "UCATApplicationDB";
--
-- Name: UCATApplicationDB; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "UCATApplicationDB" WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'C' LC_CTYPE = 'C';


ALTER DATABASE "UCATApplicationDB" OWNER TO postgres;

\connect "UCATApplicationDB"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Categories" (
    category_id integer NOT NULL,
    name text NOT NULL,
    level integer
);


ALTER TABLE public."Categories" OWNER TO postgres;

--
-- Name: Categories_category_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Categories_category_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Categories_category_id_seq" OWNER TO postgres;

--
-- Name: Categories_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Categories_category_id_seq" OWNED BY public."Categories".category_id;


--
-- Name: Structure; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Structure" (
    structure_id integer NOT NULL,
    name text NOT NULL,
    description text,
    section_order integer[],
    type text NOT NULL,
    "time" integer
);


ALTER TABLE public."Structure" OWNER TO postgres;

--
-- Name: Exams_exam_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Exams_exam_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Exams_exam_id_seq" OWNER TO postgres;

--
-- Name: Exams_exam_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Exams_exam_id_seq" OWNED BY public."Structure".structure_id;


--
-- Name: Question_Stems; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Question_Stems" (
    stem_id integer NOT NULL,
    text text NOT NULL,
    question_order integer[]
);


ALTER TABLE public."Question_Stems" OWNER TO postgres;

--
-- Name: Question_Stems_stem_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Question_Stems_stem_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Question_Stems_stem_id_seq" OWNER TO postgres;

--
-- Name: Question_Stems_stem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Question_Stems_stem_id_seq" OWNED BY public."Question_Stems".stem_id;


--
-- Name: Questions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Questions" (
    question_id integer NOT NULL,
    type text NOT NULL,
    options text[],
    question text NOT NULL,
    answer text NOT NULL,
    explanation text,
    difficulty integer,
    category_id integer NOT NULL,
    stem_id integer
);


ALTER TABLE public."Questions" OWNER TO postgres;

--
-- Name: Questions_question_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Questions_question_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Questions_question_id_seq" OWNER TO postgres;

--
-- Name: Questions_question_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Questions_question_id_seq" OWNED BY public."Questions".question_id;


--
-- Name: Responses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Responses" (
    response_id integer NOT NULL,
    value text,
    flagged boolean NOT NULL,
    session_id integer NOT NULL,
    student_id integer NOT NULL,
    question_id integer NOT NULL,
    section_id integer NOT NULL,
    "timestamp" timestamp without time zone NOT NULL,
    correct boolean
);


ALTER TABLE public."Responses" OWNER TO postgres;

--
-- Name: Responses_response_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Responses_response_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Responses_response_id_seq" OWNER TO postgres;

--
-- Name: Responses_response_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Responses_response_id_seq" OWNED BY public."Responses".response_id;


--
-- Name: Sections; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Sections" (
    section_id integer NOT NULL,
    name text NOT NULL,
    description text,
    question_order integer[],
    "time" integer
);


ALTER TABLE public."Sections" OWNER TO postgres;

--
-- Name: Sections_Questions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Sections_Questions" (
    section_id integer NOT NULL,
    question_id integer NOT NULL
);


ALTER TABLE public."Sections_Questions" OWNER TO postgres;

--
-- Name: Sections_section_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Sections_section_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Sections_section_id_seq" OWNER TO postgres;

--
-- Name: Sections_section_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Sections_section_id_seq" OWNED BY public."Sections".section_id;


--
-- Name: Sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Sessions" (
    session_id integer NOT NULL,
    completed boolean NOT NULL,
    score integer,
    structure_id integer NOT NULL,
    student_id integer NOT NULL,
    start_time timestamp without time zone[],
    end_time timestamp without time zone[],
    score_breakdown json
);


ALTER TABLE public."Sessions" OWNER TO postgres;

--
-- Name: Sessions_session_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Sessions_session_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Sessions_session_id_seq" OWNER TO postgres;

--
-- Name: Sessions_session_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Sessions_session_id_seq" OWNED BY public."Sessions".session_id;


--
-- Name: Structures_Sections; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Structures_Sections" (
    structure_id integer NOT NULL,
    section_id integer NOT NULL
);


ALTER TABLE public."Structures_Sections" OWNER TO postgres;

--
-- Name: Students; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Students" (
    student_id integer NOT NULL,
    username text NOT NULL
);


ALTER TABLE public."Students" OWNER TO postgres;

--
-- Name: Students_student_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Students_student_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Students_student_id_seq" OWNER TO postgres;

--
-- Name: Students_student_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Students_student_id_seq" OWNED BY public."Students".student_id;


--
-- Name: Categories category_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Categories" ALTER COLUMN category_id SET DEFAULT nextval('public."Categories_category_id_seq"'::regclass);


--
-- Name: Question_Stems stem_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Question_Stems" ALTER COLUMN stem_id SET DEFAULT nextval('public."Question_Stems_stem_id_seq"'::regclass);


--
-- Name: Questions question_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Questions" ALTER COLUMN question_id SET DEFAULT nextval('public."Questions_question_id_seq"'::regclass);


--
-- Name: Responses response_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Responses" ALTER COLUMN response_id SET DEFAULT nextval('public."Responses_response_id_seq"'::regclass);


--
-- Name: Sections section_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Sections" ALTER COLUMN section_id SET DEFAULT nextval('public."Sections_section_id_seq"'::regclass);


--
-- Name: Sessions session_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Sessions" ALTER COLUMN session_id SET DEFAULT nextval('public."Sessions_session_id_seq"'::regclass);


--
-- Name: Structure structure_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Structure" ALTER COLUMN structure_id SET DEFAULT nextval('public."Exams_exam_id_seq"'::regclass);


--
-- Name: Students student_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students" ALTER COLUMN student_id SET DEFAULT nextval('public."Students_student_id_seq"'::regclass);


--
-- Data for Name: Categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Categories" (category_id, name, level) FROM stdin;
\.
COPY public."Categories" (category_id, name, level) FROM '$$PATH$$/3247.dat';

--
-- Data for Name: Question_Stems; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Question_Stems" (stem_id, text, question_order) FROM stdin;
\.
COPY public."Question_Stems" (stem_id, text, question_order) FROM '$$PATH$$/3253.dat';

--
-- Data for Name: Questions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Questions" (question_id, type, options, question, answer, explanation, difficulty, category_id, stem_id) FROM stdin;
\.
COPY public."Questions" (question_id, type, options, question, answer, explanation, difficulty, category_id, stem_id) FROM '$$PATH$$/3236.dat';

--
-- Data for Name: Responses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Responses" (response_id, value, flagged, session_id, student_id, question_id, section_id, "timestamp", correct) FROM stdin;
\.
COPY public."Responses" (response_id, value, flagged, session_id, student_id, question_id, section_id, "timestamp", correct) FROM '$$PATH$$/3243.dat';

--
-- Data for Name: Sections; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Sections" (section_id, name, description, question_order, "time") FROM stdin;
\.
COPY public."Sections" (section_id, name, description, question_order, "time") FROM '$$PATH$$/3249.dat';

--
-- Data for Name: Sections_Questions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Sections_Questions" (section_id, question_id) FROM stdin;
\.
COPY public."Sections_Questions" (section_id, question_id) FROM '$$PATH$$/3250.dat';

--
-- Data for Name: Sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Sessions" (session_id, completed, score, structure_id, student_id, start_time, end_time, score_breakdown) FROM stdin;
\.
COPY public."Sessions" (session_id, completed, score, structure_id, student_id, start_time, end_time, score_breakdown) FROM '$$PATH$$/3241.dat';

--
-- Data for Name: Structure; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Structure" (structure_id, name, description, section_order, type, "time") FROM stdin;
\.
COPY public."Structure" (structure_id, name, description, section_order, type, "time") FROM '$$PATH$$/3239.dat';

--
-- Data for Name: Structures_Sections; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Structures_Sections" (structure_id, section_id) FROM stdin;
\.
COPY public."Structures_Sections" (structure_id, section_id) FROM '$$PATH$$/3251.dat';

--
-- Data for Name: Students; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Students" (student_id, username) FROM stdin;
\.
COPY public."Students" (student_id, username) FROM '$$PATH$$/3245.dat';

--
-- Name: Categories_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Categories_category_id_seq"', 2, true);


--
-- Name: Exams_exam_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Exams_exam_id_seq"', 8, true);


--
-- Name: Question_Stems_stem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Question_Stems_stem_id_seq"', 1, true);


--
-- Name: Questions_question_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Questions_question_id_seq"', 20, true);


--
-- Name: Responses_response_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Responses_response_id_seq"', 812, true);


--
-- Name: Sections_section_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Sections_section_id_seq"', 4, true);


--
-- Name: Sessions_session_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Sessions_session_id_seq"', 531, true);


--
-- Name: Students_student_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Students_student_id_seq"', 33, true);


--
-- Name: Categories Categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Categories"
    ADD CONSTRAINT "Categories_pkey" PRIMARY KEY (category_id);


--
-- Name: Structure Exams_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Structure"
    ADD CONSTRAINT "Exams_pkey" PRIMARY KEY (structure_id);


--
-- Name: Question_Stems Question_Stems_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Question_Stems"
    ADD CONSTRAINT "Question_Stems_pkey" PRIMARY KEY (stem_id);


--
-- Name: Questions Questions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Questions"
    ADD CONSTRAINT "Questions_pkey" PRIMARY KEY (question_id);


--
-- Name: Responses Responses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Responses"
    ADD CONSTRAINT "Responses_pkey" PRIMARY KEY (response_id);


--
-- Name: Sections_Questions Sections_Questions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Sections_Questions"
    ADD CONSTRAINT "Sections_Questions_pkey" PRIMARY KEY (section_id, question_id);


--
-- Name: Sections Sections_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Sections"
    ADD CONSTRAINT "Sections_pkey" PRIMARY KEY (section_id);


--
-- Name: Sessions Sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Sessions"
    ADD CONSTRAINT "Sessions_pkey" PRIMARY KEY (session_id);


--
-- Name: Structures_Sections Structures_Sections_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Structures_Sections"
    ADD CONSTRAINT "Structures_Sections_pkey" PRIMARY KEY (structure_id, section_id);


--
-- Name: Students Students_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_pkey" PRIMARY KEY (student_id);


--
-- Name: fki_question_id_fkey; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_question_id_fkey ON public."Sections_Questions" USING btree (question_id);


--
-- Name: fki_section_id_fkey; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_section_id_fkey ON public."Sections_Questions" USING btree (section_id);


--
-- Name: fki_session_id_fkey; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_session_id_fkey ON public."Responses" USING btree (session_id);


--
-- Name: fki_stem_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_stem_id ON public."Questions" USING btree (stem_id);


--
-- Name: fki_structure_id_fkey; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_structure_id_fkey ON public."Structures_Sections" USING btree (structure_id);


--
-- Name: Questions category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Questions"
    ADD CONSTRAINT category_id_fkey FOREIGN KEY (category_id) REFERENCES public."Categories"(category_id) NOT VALID;


--
-- Name: Sessions current_section_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Sessions"
    ADD CONSTRAINT current_section_id_fkey FOREIGN KEY (session_id) REFERENCES public."Sessions"(session_id) NOT VALID;


--
-- Name: Responses question_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Responses"
    ADD CONSTRAINT question_id_fkey FOREIGN KEY (question_id) REFERENCES public."Questions"(question_id) NOT VALID;


--
-- Name: Sections_Questions question_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Sections_Questions"
    ADD CONSTRAINT question_id_fkey FOREIGN KEY (question_id) REFERENCES public."Questions"(question_id) ON DELETE CASCADE NOT VALID;


--
-- Name: Sections_Questions section_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Sections_Questions"
    ADD CONSTRAINT section_id_fkey FOREIGN KEY (section_id) REFERENCES public."Sections"(section_id) ON DELETE CASCADE NOT VALID;


--
-- Name: Structures_Sections section_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Structures_Sections"
    ADD CONSTRAINT section_id_fkey FOREIGN KEY (section_id) REFERENCES public."Sections"(section_id) ON DELETE CASCADE NOT VALID;


--
-- Name: Responses section_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Responses"
    ADD CONSTRAINT section_id_fkey FOREIGN KEY (section_id) REFERENCES public."Sections"(section_id) NOT VALID;


--
-- Name: Responses session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Responses"
    ADD CONSTRAINT session_id_fkey FOREIGN KEY (session_id) REFERENCES public."Sessions"(session_id) ON DELETE CASCADE NOT VALID;


--
-- Name: Questions stem_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Questions"
    ADD CONSTRAINT stem_id_fkey FOREIGN KEY (stem_id) REFERENCES public."Question_Stems"(stem_id) NOT VALID;


--
-- Name: Sessions structure_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Sessions"
    ADD CONSTRAINT structure_id_fkey FOREIGN KEY (structure_id) REFERENCES public."Structure"(structure_id) NOT VALID;


--
-- Name: Structures_Sections structure_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Structures_Sections"
    ADD CONSTRAINT structure_id_fkey FOREIGN KEY (structure_id) REFERENCES public."Structure"(structure_id) ON DELETE CASCADE NOT VALID;


--
-- Name: Sessions student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Sessions"
    ADD CONSTRAINT student_id_fkey FOREIGN KEY (student_id) REFERENCES public."Students"(student_id) NOT VALID;


--
-- Name: Responses student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Responses"
    ADD CONSTRAINT student_id_fkey FOREIGN KEY (student_id) REFERENCES public."Students"(student_id) NOT VALID;


--
-- PostgreSQL database dump complete
--

